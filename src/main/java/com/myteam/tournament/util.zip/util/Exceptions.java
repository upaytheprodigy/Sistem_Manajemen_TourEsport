public class Exceptions {
    
}
