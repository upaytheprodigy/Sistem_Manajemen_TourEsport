public class StrategyTest {
    
}
